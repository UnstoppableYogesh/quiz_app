
<?php $__env->startSection('myQuiz_select', 'active'); ?>
<?php $__env->startSection('container'); ?>
<!-- Content wrapper -->

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-lg-8 mb-4 order-0">
            <div class="card">
                <div class="d-flex align-items-end row">
                    <div class="col-sm-7">
                        <div class="card-body">
                            <h5 class="card-title text-primary">Multiple Choice Question 📝</h5>
                            <form method="POST" action="">
                                <?php echo csrf_field(); ?>
                                <!-- Question 1 -->
                                <?php
                                    $i=1;
                                ?>
                                <?php $__currentLoopData = $groupedQuizData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qid => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mb-4">
                                        <p><?php echo e($loop->iteration); ?>. <?php echo e($data[0]->quiz_name); ?></p>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="q<?php echo e($loop->parent->index + 1); ?>" id="q<?php echo e($loop->parent->index + 1); ?>_option<?php echo e($ans->qid); ?>" value="<?php echo e($ans->answer_text); ?>">
                                                <label class="form-check-label" for="q<?php echo e($loop->parent->index + 1); ?>_option<?php echo e($ans->qid); ?>">
                                                    <?php echo e($ans->answer_text); ?>

                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                                <!-- Add more questions as needed -->
                                <button type="submit" class="btn btn-primary" name="submit" >Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mcq_app\resources\views/quiz-app.blade.php ENDPATH**/ ?>