## create userauthentication
steps 1 create controller
cmd - php artisan make:controller Auth -mcr 

## create middleware
php artisan make:middleware UserAuth
using group middleware

        'user_auth' => [
           \App\Http\Middleware\UserAuth::class,
        ], 
        
configure in karnal.php

