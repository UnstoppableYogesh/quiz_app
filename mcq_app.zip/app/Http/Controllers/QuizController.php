<?php

namespace App\Http\Controllers;

use App\Models\Quiz;
use Illuminate\Http\Request;

//
use Illuminate\Support\Facades\DB;


class QuizController extends Controller
{
    
    public function index()
    {
        $quizData = DB::table('quizzes')
            ->join('answers', 'quizzes.qid', '=', 'answers.ans_id')
            ->select('quizzes.qid', 'quizzes.quiz_name', 'answers.answer_text')
            ->get();

        // Group the answers by quiz ID
        $groupedQuizData = $quizData->groupBy('qid');

        return view('quiz-app', compact('groupedQuizData'));
    }
    // public function index()
    // {
    //     $quizzes = Quiz::with('quizzes.answers')->get();

    //     return view('quiz-app', compact('quizzes'));
    // }

    public function store(Request $request)
    {
        //
    }

    public function show(Quiz $quiz)
    {
        //
    }

    public function edit(Quiz $quiz)
    {
        //
    }

    public function update(Request $request, Quiz $quiz)
    {
        //
    }

    public function destroy(Quiz $quiz)
    {
        //
    }
}
