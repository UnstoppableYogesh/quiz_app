<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Http\Request;

//import class
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;


class UsersController extends Controller
{
    public function index(Request $request)
    {
        if ($request->session()->has('USER_LOGIN')) {
            return redirect('dashboard')->with('message', 'You are already logged in');
        } else {
            $message = 'Prevent to access this page';
            return view('LoginAuth', compact('message'));
        }
        return view('LoginAuth');
    }

    public function auth(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);
    
        $username = $request->input('username');
        $password = $request->input('password');
    
        $result = Users::where('username', $username)->first();
    
        if ($result) {
            if (Hash::check($password, $result->password)) {
                $request->session()->put('USER_LOGIN', true);
                $request->session()->put('USER_ID', $result->uid);
    
                return redirect('dashboard');
            } else {
                return redirect('/')
                    ->with('error', 'Password is incorrect')
                    ->withInput();
            }
        } else {
            return redirect('/')
                ->with('error', 'Username not found')
                ->withInput()
                ->withErrors(['username' => 'Username not found']); 
        }
    }

    public function signup(){
        return view('auth-signup');
    }
    
    //create a new account
    public function store(Request $request){
        $validator = Validator::make($request->all(), [
            'username' => 'required',
            'password' => 'required|min:6|confirmed',
            'email' => 'required|email',
        ]);
    
        // Check if validation fails
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
    
        try {
            DB::table('users')->insert([
                'username' => $request->input('username'),
                'email' => $request->input('email'),
                'password' => Hash::make($request->input('password')),
            ]);

            Session::flash('success', 'Your account has been created successfully.');
            return redirect()->route('signup'); //('auth-signup')->with('message', 'Account created successfully');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'An error occurred while creating the account.');
        }
    }
    


    public function dashboard(){
        return view('dashboard');
    }

    public function updatepassword()
    {
         $r=Users::find(1);
         $r->password=Hash::make('test');
         $r->save();
    }
}
