<?php

use Illuminate\Support\Facades\Route;

//target class error fix 
use App\Http\Controllers\UsersController;
use App\Http\Controllers\QuizController;

Route::get('/', [UsersController::class, 'index']);
Route::post('/', [UsersController::class, 'auth'])->name('auth');
Route::get('auth-signup', [UsersController::class, 'signup'])->name('signup');
Route::post('auth-signup', [UsersController::class, 'store'])->name('signup');

Route::get('updatepassword',[UsersController::class, 'updatepassword']);


//middleware 
Route::group(['middleware' => 'user_auth'], function(){
    //
    Route::get('dashboard',[UsersController::class, 'dashboard'])->name('dashboard');
    
    //myQuiz
    Route::get('quiz-app', [QuizController::class, 'index'])->name('myQuiz');
    Route::post('quiz-app', [QuizController::class, 'store']);//->name('myQuiz');
    


    //logout script
    Route::get('logout',[UsersController::class, 'logout']);
    Route::get('logout', function () {
        session()->forget('USER_LOGIN');
        session()->forget('USER_ID');
    
        Session::flash('swal_message', 'Logout Successfully');
        Session::flash('swal_type', 'success');
        return redirect('/');
    });
});