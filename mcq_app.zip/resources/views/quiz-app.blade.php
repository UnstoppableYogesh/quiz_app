@extends('components/layout')
@section('myQuiz_select', 'active')
@section('container')
<!-- Content wrapper -->
{{-- <div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">
    <div class="col-lg-8 mb-4 order-0">
      <div class="card">
        <div class="d-flex align-items-end row">
          <div class="col-sm-7">
            <div class="card-body">
              <h5 class="card-title text-primary">Congratulations John! 🎉</h5>
              <p class="mb-4">
                You have done <span class="fw-bold">72%</span> more sales today. Check your new badge in
                your profile.
              </p>
              <a href="javascript:;" class="btn btn-sm btn-outline-primary">View Badges</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>   --}}
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-lg-8 mb-4 order-0">
            <div class="card">
                <div class="d-flex align-items-end row">
                    <div class="col-sm-7">
                        <div class="card-body">
                            <h5 class="card-title text-primary">Multiple Choice Question 📝</h5>
                            <form method="POST" action="">
                                @csrf
                                <!-- Question 1 -->
                                @php
                                    $i=1;
                                @endphp
                                @foreach ($groupedQuizData as $qid => $data)
                                    <div class="mb-4">
                                        <p>{{$loop->iteration}}. {{$data[0]->quiz_name}}</p>
                                        @foreach ($data as $ans)
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="q{{$loop->parent->index + 1}}" id="q{{$loop->parent->index + 1}}_option{{$ans->qid}}" value="{{$ans->answer_text}}">
                                                <label class="form-check-label" for="q{{$loop->parent->index + 1}}_option{{$ans->qid}}">
                                                    {{$ans->answer_text}}
                                                </label>
                                            </div>
                                        @endforeach
                                    </div>
                                @endforeach
                               
                                <!-- Add more questions as needed -->
                                <button type="submit" class="btn btn-primary" name="submit" >Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
